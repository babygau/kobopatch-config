local _ = require("gettext")
return {
    name = "goodreads",
    fullname = _("Goodreads"),
    description = _([[Allows browsing and searching the Goodreads database of books.]]),
}
