local _ = require("gettext")
return {
    name = "evernote",
    fullname = _("Evernote"),
    description = _([[Exports highlights and notes to the Evernote cloud.]]),
}
