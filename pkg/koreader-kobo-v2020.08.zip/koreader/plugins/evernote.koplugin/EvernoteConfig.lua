
local EvernoteConfig = {}

-- !!! DO NOT EDIT !!!
EvernoteConfig.BASE_URL = "https://www.evernote.com"
EvernoteConfig.USER_STORE_URL = "https://www.evernote.com/edam/user"
EvernoteConfig.CONSUMER_KEY = "koreader-0563"
EvernoteConfig.CONSUMER_SECRET = "c0f923319afb8e90"

EvernoteConfig.BASE_URL_YINXIANG = "https://app.yinxiang.com"
EvernoteConfig.USER_STORE_URL_YINXIANG = "https://app.yinxiang.com/edam/user"
EvernoteConfig.CONSUMER_KEY_YINXIANG = "koreader-0563"
EvernoteConfig.CONSUMER_SECRET_YINXIANG = "c0f923319afb8e90"

EvernoteConfig.BASE_URL_SANDBOX = "https://sandbox.evernote.com"
EvernoteConfig.USER_STORE_URL_SANDBOX = "https://sandbox.evernote.com/edam/user"
EvernoteConfig.CONSUMER_KEY_SANDBOX = "chrox-1362"
EvernoteConfig.CONSUMER_SECRET_SANDBOX = "cb1c81d0a5bc05d5"
-- !!! DO NOT EDIT !!!

return EvernoteConfig

