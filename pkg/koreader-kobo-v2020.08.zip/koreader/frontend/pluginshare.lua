-- PluginShare is a table for plugins to exchange data between each other. Plugins should maintain
-- their own protocols.
return {
    backgroundJobs = {},
}
